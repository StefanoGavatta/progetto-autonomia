import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes),
    // provideHttpClient() mette a disposizione dell'applicazione un servizio (da utilizzare con
    // Dependency Injection) per inviare richieste HTTP
    provideHttpClient()
  ]
};
  // provideHttpClient() mette a disposizione del'applicazione un servizio (da utilizzare con Dependency Injecton) per inviare richieste HTTP
