import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { SpotifyService } from './spotify.service';

export const tokenOkGuard: CanActivateFn = (route, state) => {
  //inietto il servizio SpotifyService nella funzione.
  //attezione che tokenGuard è una function, NON posso usare le parole 
  //chiave private o altro , devo dichiarare o una variable con let o una costante con const.
  //la scelta piu comune è const
  const spotifyServices: SpotifyService = inject(SpotifyService);
  const router: Router = inject(Router);

  //controllo se dipo no del token 

  if(spotifyServices.tokenOK()){
    //il token presente si può accedere al componente che usa questa guardia 
    return true;
  }else{
    router.navigateByUrl('/');
        //proibiamo l'accesso al componente
      return false;
  }
};
