import { Component, Input, InputSignal } from '@angular/core';
import { Item } from '../i-albums';

@Component({
  selector: 'app-album-card',
  standalone: true,
  imports: [],
  templateUrl: './album-card.component.html',
  styleUrls: ['./album-card.component.css']
})
export class AlbumCardComponent {
  album: InputSignal<Item> = Input.required();

  get artists(): string {
    return this.album().artists?.map((artist: any) => artist.name).join(', ') || '';
  }
}